package com.tpar.notasalunosprofessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotasalunosprofessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
