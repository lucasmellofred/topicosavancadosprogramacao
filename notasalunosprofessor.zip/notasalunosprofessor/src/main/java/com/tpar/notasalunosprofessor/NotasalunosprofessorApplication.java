package com.tpar.notasalunosprofessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotasalunosprofessorApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotasalunosprofessorApplication.class, args);
	}
}